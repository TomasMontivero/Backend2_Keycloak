package com.dh.keycloakrunner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeycloakRunnerApplicationTests {

	@Test
	void contextLoads() {
	}

}
